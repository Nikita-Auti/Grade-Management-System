package com.devdaljeet.grademanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradeManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
